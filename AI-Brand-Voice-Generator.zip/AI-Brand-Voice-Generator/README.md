# AI Brand Voice Generator — Final Year Project

A submission-ready MVP web application using React, Spring Boot, MySQL and Google's Gemini API.

## Features
- Register / login
- Create multiple brands
- Add sample marketing text
- Analyze brand voice with Gemini
- Generate Instagram posts, emails, taglines, ad headlines, blog intros and product announcements
- Copy generated content
- Store brand and generated content data in MySQL

## Architecture
React → Spring Boot REST API → Gemini API / MySQL

## Important
The Gemini API key must be kept server-side as `GEMINI_API_KEY`; never commit a real key to Git.

## Run backend
1. Install Java 23, Maven and MySQL.
2. Set DB_USERNAME, DB_PASSWORD and GEMINI_API_KEY.
3. In `backend`: `mvn spring-boot:run`

## Run frontend
1. Install Node.js 18+.
2. In `frontend`: `npm install` then `npm run dev`.
3. Open http://localhost:5173.

## API endpoints
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/brands/user/{userId}`
- POST `/api/brands?userId={userId}`
- POST `/api/brands/{id}/samples`
- POST `/api/brands/{id}/analyze`
- POST `/api/brands/{id}/generate`
- GET `/api/brands/{id}/history`
