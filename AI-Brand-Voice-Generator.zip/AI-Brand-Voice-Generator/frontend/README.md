# Frontend - AI Brand Voice Generator

## Requirements
Node.js 18+

## Run
npm install
npm run dev

Open http://localhost:5173
