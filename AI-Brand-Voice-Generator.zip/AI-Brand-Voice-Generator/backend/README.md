# Backend - AI Brand Voice Generator

## Requirements
- Java 23
- Maven 3.9+
- MySQL 8+
- Gemini API key

## Run
1. Create MySQL database `brandvoice` (or let Hibernate create it).
2. Set `DB_USERNAME`, `DB_PASSWORD`, and `GEMINI_API_KEY` environment variables.
3. `mvn spring-boot:run`
4. Backend runs at `http://localhost:8080`.

The Gemini integration uses Google's `generateContent` REST endpoint. Keep the API key on the server and never commit it.
