package com.brandvoice.dto; public record GenerateRequest(Long brandId,String contentType,String topic,String audience,String platform,String extraInstructions) {}
