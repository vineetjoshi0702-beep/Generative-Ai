package com.brandvoice.dto; public record RegisterRequest(String name,String email,String password) {}
