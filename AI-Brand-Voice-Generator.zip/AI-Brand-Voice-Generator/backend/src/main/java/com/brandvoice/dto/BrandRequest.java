package com.brandvoice.dto; public record BrandRequest(String name,String industry,String description) {}
