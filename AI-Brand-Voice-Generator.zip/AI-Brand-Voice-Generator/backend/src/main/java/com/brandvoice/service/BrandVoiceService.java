package com.brandvoice.service;

import com.brandvoice.entity.*; import com.brandvoice.repository.*; import org.springframework.stereotype.Service; import java.time.LocalDateTime; import java.util.*;

@Service
public class BrandVoiceService {
    private final BrandRepository brands; private final BrandSampleRepository samples; private final GeneratedContentRepository generated; private final GeminiService gemini;
    public BrandVoiceService(BrandRepository b, BrandSampleRepository s, GeneratedContentRepository g, GeminiService ai){brands=b;samples=s;generated=g;gemini=ai;}

    public Brand analyze(Long brandId){
        Brand brand=brands.findById(brandId).orElseThrow(); List<BrandSample> ss=samples.findByBrandId(brandId);
        if(ss.isEmpty()) throw new IllegalArgumentException("Add at least one brand sample first.");
        String joined=ss.stream().map(x->"["+x.getContentType()+"]\n"+x.getContent()).reduce("",(a,b)->a+"\n\n"+b);
        String prompt="""
        You are a brand voice analyst. Analyze the sample marketing texts below and create a concise brand voice profile.
        Return sections: Tone, Personality, Vocabulary, Sentence Style, Emotional Attitude, Audience, Do/Don't guidelines.
        Do not copy the samples. Be practical for a content-generation system.
        BRAND: %s
        INDUSTRY: %s
        SAMPLES:
        %s
        """.formatted(brand.getName(), Optional.ofNullable(brand.getIndustry()).orElse("Not specified"), joined);
        brand.setBrandVoice(gemini.generate(prompt)); return brands.save(brand);
    }

    public GeneratedContent generate(Long brandId,String type,String topic,String audience,String platform,String extra){
        Brand b=brands.findById(brandId).orElseThrow();
        String voice=Optional.ofNullable(b.getBrandVoice()).orElse("No voice profile yet. Infer style from the brand description and samples.");
        String prompt="""
        You are an expert marketing copywriter. Generate ORIGINAL content for the brand below.
        STRICTLY follow the brand voice profile. Do not mention AI, prompts, samples, or analysis.
        Brand: %s
        Industry: %s
        Brand description: %s
        Brand voice profile: %s
        Content type: %s
        Topic/product: %s
        Audience: %s
        Platform: %s
        Extra instructions: %s
        Return only the finished content, with clean formatting.
        """.formatted(b.getName(), b.getIndustry(), b.getDescription(), voice, type, topic, audience, platform, extra);
        String content=gemini.generate(prompt);
        GeneratedContent gc=GeneratedContent.builder().brand(b).contentType(type).topic(topic).content(content).createdAt(LocalDateTime.now()).build();
        return generated.save(gc);
    }
}
