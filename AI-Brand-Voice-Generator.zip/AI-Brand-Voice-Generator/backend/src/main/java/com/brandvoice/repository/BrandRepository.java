package com.brandvoice.repository;
import com.brandvoice.entity.Brand; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface BrandRepository extends JpaRepository<Brand,Long>{ List<Brand> findByUserId(Long userId); }
