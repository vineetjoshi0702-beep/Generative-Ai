package com.brandvoice.dto; public record LoginRequest(String email,String password) {}
