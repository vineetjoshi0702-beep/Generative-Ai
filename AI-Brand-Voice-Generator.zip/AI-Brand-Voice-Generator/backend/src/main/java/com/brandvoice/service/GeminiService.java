package com.brandvoice.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import java.util.*;

@Service
public class GeminiService {
    private final RestClient client = RestClient.builder().baseUrl("https://generativelanguage.googleapis.com/v1beta").build();
    private final ObjectMapper mapper = new ObjectMapper();
    @Value("${gemini.api-key}") private String apiKey;
    @Value("${gemini.model}") private String model;

    public String generate(String prompt) {
        if (apiKey == null || apiKey.isBlank()) throw new IllegalStateException("GEMINI_API_KEY is not configured. Add it as an environment variable.");
        Map<String,Object> body = Map.of("contents", List.of(Map.of("parts", List.of(Map.of("text", prompt)))));
        String raw = client.post().uri("/models/{model}:generateContent?key={key}", model, apiKey)
                .contentType(MediaType.APPLICATION_JSON).body(body).retrieve().body(String.class);
        try {
            JsonNode root = mapper.readTree(raw);
            JsonNode text = root.path("candidates").path(0).path("content").path("parts").path(0).path("text");
            if (text.isMissingNode()) throw new IllegalStateException("Gemini returned no text: " + raw);
            return text.asText();
        } catch (Exception e) { throw new IllegalStateException("Unable to parse Gemini response: " + e.getMessage()); }
    }
}
