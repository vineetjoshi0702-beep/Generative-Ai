package com.brandvoice.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BrandSample {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(nullable=false, length=12000) private String content;
    private String contentType;
    @ManyToOne(optional=false) private Brand brand;
}
