package com.brandvoice.repository;
import com.brandvoice.entity.GeneratedContent; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface GeneratedContentRepository extends JpaRepository<GeneratedContent,Long>{ List<GeneratedContent> findByBrandUserIdOrderByCreatedAtDesc(Long userId); }
