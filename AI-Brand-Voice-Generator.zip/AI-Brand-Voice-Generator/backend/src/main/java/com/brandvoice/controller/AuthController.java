package com.brandvoice.controller;
import com.brandvoice.dto.*; import com.brandvoice.entity.AppUser; import com.brandvoice.repository.AppUserRepository; import org.springframework.http.*; import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/auth")
public class AuthController {
 private final AppUserRepository repo; private final BCryptPasswordEncoder enc=new BCryptPasswordEncoder(); public AuthController(AppUserRepository r){repo=r;}
 @PostMapping("/register") public ResponseEntity<?> register(@RequestBody RegisterRequest r){ if(repo.findByEmail(r.email()).isPresent()) return ResponseEntity.badRequest().body(Map.of("message","Email already registered")); AppUser u=AppUser.builder().name(r.name()).email(r.email()).passwordHash(enc.encode(r.password())).build(); repo.save(u); return ResponseEntity.ok(Map.of("id",u.getId(),"name",u.getName(),"email",u.getEmail())); }
 @PostMapping("/login") public ResponseEntity<?> login(@RequestBody LoginRequest r){ return repo.findByEmail(r.email()).filter(u->enc.matches(r.password(),u.getPasswordHash())).<ResponseEntity<?>>map(u->ResponseEntity.ok(Map.of("id",u.getId(),"name",u.getName(),"email",u.getEmail()))).orElseGet(()->ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("message","Invalid email or password"))); }
}
