package com.brandvoice.dto; public record SampleRequest(String content,String contentType) {}
