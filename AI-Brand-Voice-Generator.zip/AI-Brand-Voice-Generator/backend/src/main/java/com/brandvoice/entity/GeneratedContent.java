package com.brandvoice.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class GeneratedContent {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    private String contentType;
    private String topic;
    @Column(length=20000) private String content;
    private LocalDateTime createdAt;
    @ManyToOne(optional=false) private Brand brand;
}
