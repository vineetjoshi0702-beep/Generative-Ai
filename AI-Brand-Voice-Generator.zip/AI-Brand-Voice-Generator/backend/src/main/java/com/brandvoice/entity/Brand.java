package com.brandvoice.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Brand {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(nullable=false) private String name;
    private String industry;
    @Column(length=2000) private String description;
    @Column(length=10000) private String brandVoice;
    @ManyToOne(optional=false) private AppUser user;
}
