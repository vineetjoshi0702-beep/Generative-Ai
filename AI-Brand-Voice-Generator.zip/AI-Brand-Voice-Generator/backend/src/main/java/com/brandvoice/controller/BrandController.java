package com.brandvoice.controller;
import com.brandvoice.dto.*; import com.brandvoice.entity.*; import com.brandvoice.repository.*; import com.brandvoice.service.BrandVoiceService; import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/brands")
public class BrandController {
 private final BrandRepository brands; private final AppUserRepository users; private final BrandSampleRepository samples; private final GeneratedContentRepository generated; private final BrandVoiceService service;
 public BrandController(BrandRepository b,AppUserRepository u,BrandSampleRepository s,GeneratedContentRepository g,BrandVoiceService sv){brands=b;users=u;samples=s;generated=g;service=sv;}
 @GetMapping("/user/{userId}") public List<Brand> list(@PathVariable Long userId){return brands.findByUserId(userId);}
 @PostMapping public Brand create(@RequestParam Long userId,@RequestBody BrandRequest r){AppUser u=users.findById(userId).orElseThrow(); return brands.save(Brand.builder().name(r.name()).industry(r.industry()).description(r.description()).user(u).build());}
 @PostMapping("/{id}/samples") public BrandSample addSample(@PathVariable Long id,@RequestBody SampleRequest r){Brand b=brands.findById(id).orElseThrow(); return samples.save(BrandSample.builder().brand(b).content(r.content()).contentType(r.contentType()).build());}
 @GetMapping("/{id}/samples") public List<BrandSample> samples(@PathVariable Long id){return samples.findByBrandId(id);}
 @PostMapping("/{id}/analyze") public Brand analyze(@PathVariable Long id){return service.analyze(id);}
 @PostMapping("/{id}/generate") public GeneratedContent generate(@PathVariable Long id,@RequestBody GenerateRequest r){return service.generate(id,r.contentType(),r.topic(),r.audience(),r.platform(),r.extraInstructions());}
 @GetMapping("/{id}/history") public List<GeneratedContent> history(@PathVariable Long id){return generated.findAll().stream().filter(x->x.getBrand().getId().equals(id)).toList();}
}
